import * as React from "react";

export interface ButtonProps {
  /** Visual style. @default "primary" */
  variant?: "primary" | "secondary" | "ghost" | "danger" | "inverse";
  /** Control height. @default "md" */
  size?: "sm" | "md" | "lg";
  /** Stretch to fill container width. @default false */
  block?: boolean;
  /** Lucide icon name rendered before the label. */
  iconLeft?: string;
  /** Lucide icon name rendered after the label. */
  iconRight?: string;
  disabled?: boolean;
  onClick?: () => void;
  children?: React.ReactNode;
}

/** Primary action control. Pill-shaped, weight-800 label. */
export declare function Button(props: ButtonProps): React.ReactElement;
