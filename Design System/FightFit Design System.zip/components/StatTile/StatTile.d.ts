import * as React from "react";

export interface StatTileProps {
  /** Lucide icon name shown in the accent chip. */
  icon?: string;
  /** Big numeric value, e.g. "486". */
  value: string;
  /** Small unit appended to the value, e.g. "kcal". */
  unit?: string;
  /** Uppercase caption under the value. */
  label: string;
  /** Optional delta text, e.g. "+12%". */
  trend?: string;
  /** Direction of the trend pill. @default "up" */
  trendDir?: "up" | "down" | "flat";
  /** Render on a dark surface. @default false */
  onInk?: boolean;
}

/** Compact KPI tile for dashboards. */
export declare function StatTile(props: StatTileProps): React.ReactElement;
