# FightFit Design System

A bold, athletic design system for a boxing-meets-fitness training app. Built from the FightFit flame-glove logo: one decisive orange accent, heavy condensed display type, warm ink neutrals, and punchy fast motion.

## Personality
Energetic, disciplined, no-nonsense. Speaks in second person, short imperative lines ("Start workout", "Every round counts"). Confident but never aggressive. The orange is earned — used as the single accent, never diluted into gradients or rainbow palettes.

## Foundations

### Color
- **Brand orange** `--ff-orange-500` (#F4661A), sampled from the logo flame/wordmark. This is the *only* accent — use it for primary actions, active states, and key stats. Full ramp `--ff-orange-50…900`.
- **Ink + warm neutrals** `--ff-ink` (#171517) plus `--ff-gray-50…900` (warm-tinted, not pure gray). Text, borders, surfaces.
- **Two surface worlds**: light (`--surface-page`, `--surface-card`) for everyday screens; **ink** (`--surface-ink`, `--surface-ink-raised`) for heroes, footers, and immersive workout views. On ink use `--text-inverse`, `--border-on-ink`.
- **Semantic status** (`--ff-success/warning/danger` + `*-soft` tints) used sparingly, always solid-on-soft.

### Type
- **Display — Barlow Condensed 700, ALWAYS uppercase**, leading `0.95`. Headlines, workout titles, section heads. Scale `--text-display-sm…xl`.
- **Body/UI — Manrope** (geometric-rounded, echoes the wordmark). Scale `--text-xs…lg`, leading `1.55`.
- **Stats — Manrope 800 with `tabular-nums`** for timers, macros, KPIs. `--text-stat-md/lg`.
- **Labels/eyebrows** — Manrope 800 uppercase, `--tracking-label` (+10%).
> Fonts are Google-Fonts stand-ins chosen to match the wordmark — swap `tokens/fonts.css` for licensed brand fonts when available.

### Spacing, radius, elevation
- 4px base scale `--space-1…24`.
- Radii: **pill** for all buttons/badges/tags, **16px** (`--radius-lg`) for cards, **24px** (`--radius-xl`) for sheets, **8px** inputs.
- Elevation leans on borders first; shadows are low and warm (`--shadow-card`, `--shadow-overlay`).
- Motion: fast ease-out `--ease-punch`, `120/200/320ms`. Punchy, no bounce.

## Components
React (`.jsx`), styled with inline token references. Mount via `window.FightFitDesignSystem_c43baf`.

| | |
|---|---|
| **Button** | 5 variants (primary/secondary/ghost/danger/inverse) × 3 sizes, pill, icon slots |
| **Badge** | status & category pills, soft/solid, 5 tones |
| **Icon** | Lucide stroke icons, lazy-loaded, 2px weight |
| **Input** | label + leading icon + hint/error states |
| **SegmentedControl** | 2–4 options, light + on-ink |
| **Toggle** | binary switch, orange active track |
| **ProgressRing** | circular goal/macro/session progress |
| **StatTile** | KPI tile with icon chip + trend, light + ink |
| **Avatar** | image/initials, status dot, orange ring |
| **WorkoutCard** | image-led class card with hover lift |
| **ExerciseRow** | exercise line with index + completion toggle |

## Templates
Starting points consuming projects can copy — see the Templates group:
- **FightFit App — Today** (`templates/app-today/`): mobile training dashboard.
- **FightFit Landing** (`templates/landing/`): marketing hero + class grid.

## Using it
```js
const { Button, StatTile, ProgressRing } = window.FightFitDesignSystem_c43baf;
```
Load `styles.css` for tokens and `_ds_bundle.js` for components. Keep the orange singular, the display type uppercase, and the copy short.
