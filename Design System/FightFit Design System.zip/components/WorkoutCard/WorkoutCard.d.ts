import * as React from "react";

export interface WorkoutCardProps {
  /** Background image URL. */
  image?: string;
  /** Category tag, e.g. "Boxing". */
  tag?: string;
  title: string;
  /** Duration text, e.g. "32 min". */
  duration?: string;
  /** Difficulty level. @default "Intermediate" */
  level?: "Beginner" | "Intermediate" | "Advanced";
  /** Estimated calorie burn, e.g. "420". */
  kcal?: string;
  onClick?: () => void;
}

/** Image-led workout card for class / session browsing. */
export declare function WorkoutCard(props: WorkoutCardProps): React.ReactElement;
