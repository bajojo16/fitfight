import * as React from "react";
import { Icon } from "../Icon/Icon.jsx";

const SIZES = {
  sm: { height: 36, padding: "0 16px", font: "var(--text-sm)", icon: 16 },
  md: { height: 44, padding: "0 22px", font: "var(--text-md)", icon: 18 },
  lg: { height: 54, padding: "0 30px", font: "var(--text-lg)", icon: 20 },
};

const VARIANTS = {
  primary: { background: "var(--color-primary)", color: "#fff", border: "1px solid transparent" },
  secondary: { background: "var(--surface-card)", color: "var(--text-primary)", border: "1px solid var(--border-strong)" },
  ghost: { background: "transparent", color: "var(--text-brand)", border: "1px solid transparent" },
  danger: { background: "var(--ff-danger)", color: "#fff", border: "1px solid transparent" },
  inverse: { background: "#fff", color: "var(--ff-ink)", border: "1px solid transparent" },
};

export function Button({
  variant = "primary",
  size = "md",
  block = false,
  iconLeft,
  iconRight,
  disabled = false,
  onClick,
  children,
}) {
  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);
  const s = SIZES[size] || SIZES.md;
  const v = VARIANTS[variant] || VARIANTS.primary;

  const hoverBg = {
    primary: "var(--color-primary-hover)",
    secondary: "var(--ff-gray-50)",
    ghost: "var(--ff-orange-50)",
    danger: "#bf2419",
    inverse: "var(--ff-gray-100)",
  }[variant];

  const style = {
    display: block ? "flex" : "inline-flex",
    width: block ? "100%" : "auto",
    alignItems: "center",
    justifyContent: "center",
    gap: "var(--space-2)",
    height: s.height,
    padding: s.padding,
    boxSizing: "border-box",
    fontFamily: "var(--font-body)",
    fontSize: s.font,
    fontWeight: "var(--weight-heavy)",
    lineHeight: 1,
    letterSpacing: "0.01em",
    borderRadius: "var(--radius-pill)",
    cursor: disabled ? "not-allowed" : "pointer",
    opacity: disabled ? 0.45 : 1,
    background: hover && !disabled ? hoverBg : v.background,
    color: v.color,
    border: v.border,
    transform: active && !disabled ? "scale(0.97)" : "scale(1)",
    transition: "background var(--duration-fast) var(--ease-punch), transform var(--duration-fast) var(--ease-punch)",
    outline: "none",
    whiteSpace: "nowrap",
  };

  return (
    <button
      type="button"
      style={style}
      disabled={disabled}
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => { setHover(false); setActive(false); }}
      onMouseDown={() => setActive(true)}
      onMouseUp={() => setActive(false)}
      onFocus={(e) => (e.currentTarget.style.boxShadow = "var(--focus-ring)")}
      onBlur={(e) => (e.currentTarget.style.boxShadow = "none")}
    >
      {iconLeft && <Icon name={iconLeft} size={s.icon} />}
      {children}
      {iconRight && <Icon name={iconRight} size={s.icon} />}
    </button>
  );
}
