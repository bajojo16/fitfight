import * as React from "react";
import { Icon } from "../Icon/Icon.jsx";
import { Badge } from "../Badge/Badge.jsx";

export function WorkoutCard({ image, tag, title, duration, level = "Intermediate", kcal, onClick }) {
  const [hover, setHover] = React.useState(false);

  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        position: "relative",
        display: "flex",
        flexDirection: "column",
        justifyContent: "flex-end",
        minHeight: 220,
        padding: "var(--space-5)",
        borderRadius: "var(--radius-lg)",
        overflow: "hidden",
        cursor: onClick ? "pointer" : "default",
        background: "var(--ff-gray-800)",
        boxShadow: hover ? "var(--shadow-overlay)" : "var(--shadow-card)",
        transform: hover ? "translateY(-3px)" : "translateY(0)",
        transition: "transform var(--duration-base) var(--ease-punch), box-shadow var(--duration-base) var(--ease-punch)",
      }}
    >
      {image && (
        <img
          src={image}
          alt=""
          style={{
            position: "absolute",
            inset: 0,
            width: "100%",
            height: "100%",
            objectFit: "cover",
            transform: hover ? "scale(1.06)" : "scale(1)",
            transition: "transform var(--duration-slow) var(--ease-punch)",
          }}
        />
      )}
      <div style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg, rgba(23,21,23,0) 30%, rgba(23,21,23,0.82) 100%)" }} />
      {tag && (
        <div style={{ position: "absolute", top: "var(--space-4)", left: "var(--space-4)" }}>
          <Badge tone="brand" variant="solid">{tag}</Badge>
        </div>
      )}
      <div style={{ position: "relative", display: "flex", flexDirection: "column", gap: "var(--space-3)" }}>
        <h3
          style={{
            margin: 0,
            fontFamily: "var(--font-display)",
            fontWeight: "var(--weight-bold)",
            textTransform: "uppercase",
            lineHeight: "var(--leading-display)",
            letterSpacing: "var(--tracking-display)",
            fontSize: "var(--text-display-sm)",
            color: "#fff",
          }}
        >
          {title}
        </h3>
        <div style={{ display: "flex", gap: "var(--space-4)", color: "rgba(255,255,255,0.86)", fontSize: "var(--text-sm)", fontWeight: "var(--weight-bold)" }}>
          {duration && (
            <span style={{ display: "inline-flex", alignItems: "center", gap: 5 }}>
              <Icon name="clock" size={15} /> {duration}
            </span>
          )}
          {kcal && (
            <span style={{ display: "inline-flex", alignItems: "center", gap: 5 }}>
              <Icon name="flame" size={15} /> {kcal} kcal
            </span>
          )}
          <span style={{ display: "inline-flex", alignItems: "center", gap: 5 }}>
            <Icon name="signal" size={15} /> {level}
          </span>
        </div>
      </div>
    </div>
  );
}
