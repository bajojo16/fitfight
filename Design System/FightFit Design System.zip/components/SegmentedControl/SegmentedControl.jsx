import * as React from "react";

export function SegmentedControl({ options = [], value = 0, onChange, onInk = false }) {
  const [internal, setInternal] = React.useState(value);
  const active = value !== undefined ? value : internal;

  return (
    <div
      style={{
        display: "inline-flex",
        padding: 4,
        gap: 2,
        background: onInk ? "rgba(255,255,255,0.08)" : "var(--surface-sunken)",
        borderRadius: "var(--radius-pill)",
        border: onInk ? "1px solid var(--border-on-ink)" : "1px solid var(--border-subtle)",
      }}
    >
      {options.map((opt, i) => {
        const on = i === active;
        return (
          <button
            key={i}
            type="button"
            onClick={() => { setInternal(i); onChange && onChange(i); }}
            style={{
              appearance: "none",
              border: "none",
              cursor: "pointer",
              padding: "8px 18px",
              borderRadius: "var(--radius-pill)",
              fontFamily: "var(--font-body)",
              fontSize: "var(--text-sm)",
              fontWeight: "var(--weight-heavy)",
              letterSpacing: "0.02em",
              background: on ? (onInk ? "#fff" : "var(--ff-ink)") : "transparent",
              color: on ? (onInk ? "var(--ff-ink)" : "#fff") : (onInk ? "var(--text-inverse-secondary)" : "var(--text-secondary)"),
              transition: "background var(--duration-fast) var(--ease-punch), color var(--duration-fast) var(--ease-punch)",
              whiteSpace: "nowrap",
            }}
          >
            {opt}
          </button>
        );
      })}
    </div>
  );
}
