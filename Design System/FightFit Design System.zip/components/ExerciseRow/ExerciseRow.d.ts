import * as React from "react";

export interface ExerciseRowProps {
  /** Index number shown in the leading chip. */
  index?: number;
  name: string;
  /** Detail line, e.g. "3 × 12 · 40kg". */
  detail?: string;
  /** Right-aligned meta, e.g. "90s rest". */
  meta?: string;
  /** Marks the exercise as completed. @default false */
  done?: boolean;
  onToggle?: () => void;
}

/** A single exercise line inside a workout plan. */
export declare function ExerciseRow(props: ExerciseRowProps): React.ReactElement;
