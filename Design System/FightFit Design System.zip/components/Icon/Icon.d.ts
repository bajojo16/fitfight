import * as React from "react";

export interface IconProps {
  /** Lucide icon name, e.g. "flame", "dumbbell". */
  name: string;
  /** Pixel size of the square frame. @default 20 */
  size?: number;
  /** Stroke color (any CSS color). @default "currentColor" */
  color?: string;
  /** Stroke width. @default 2 */
  strokeWidth?: number;
}

/** Lucide stroke icon wrapper. */
export declare function Icon(props: IconProps): React.ReactElement;
