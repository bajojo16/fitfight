import * as React from "react";

export interface BadgeProps {
  /** Color intent. @default "neutral" */
  tone?: "neutral" | "brand" | "success" | "warning" | "danger";
  /** Filled vs. soft-tinted. @default "soft" */
  variant?: "soft" | "solid";
  /** Optional Lucide icon name before the label. */
  icon?: string;
  children?: React.ReactNode;
}

/** Small status / category label. Pill-shaped, uppercase. */
export declare function Badge(props: BadgeProps): React.ReactElement;
