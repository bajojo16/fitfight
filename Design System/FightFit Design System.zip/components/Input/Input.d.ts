import * as React from "react";

export interface InputProps {
  label?: string;
  placeholder?: string;
  value?: string;
  /** Lucide icon name shown at the start of the field. */
  icon?: string;
  /** Helper or error text below the field. */
  hint?: string;
  /** Marks the field invalid and tints the hint red. @default false */
  invalid?: boolean;
  type?: string;
  disabled?: boolean;
  onChange?: (value: string) => void;
}

/** Text input with optional label, leading icon, and hint. */
export declare function Input(props: InputProps): React.ReactElement;
