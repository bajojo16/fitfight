import * as React from "react";
import { Icon } from "../Icon/Icon.jsx";

export function Input({
  label,
  placeholder,
  value,
  icon,
  hint,
  invalid = false,
  type = "text",
  disabled = false,
  onChange,
}) {
  const [focus, setFocus] = React.useState(false);
  const [internal, setInternal] = React.useState(value || "");
  const val = value !== undefined ? value : internal;

  const borderColor = invalid
    ? "var(--ff-danger)"
    : focus
    ? "var(--color-primary)"
    : "var(--border-strong)";

  return (
    <label style={{ display: "flex", flexDirection: "column", gap: 6, fontFamily: "var(--font-body)" }}>
      {label && (
        <span style={{ fontSize: "var(--text-sm)", fontWeight: "var(--weight-bold)", color: "var(--text-primary)" }}>
          {label}
        </span>
      )}
      <span
        style={{
          display: "flex",
          alignItems: "center",
          gap: 10,
          height: 48,
          padding: "0 16px",
          background: disabled ? "var(--ff-gray-100)" : "var(--surface-card)",
          border: `1.5px solid ${borderColor}`,
          borderRadius: "var(--radius-sm)",
          boxShadow: focus ? "var(--focus-ring)" : "none",
          transition: "border-color var(--duration-fast) var(--ease-punch), box-shadow var(--duration-fast) var(--ease-punch)",
          opacity: disabled ? 0.6 : 1,
        }}
      >
        {icon && <Icon name={icon} size={18} color="var(--text-muted)" />}
        <input
          type={type}
          value={val}
          placeholder={placeholder}
          disabled={disabled}
          onChange={(e) => { setInternal(e.target.value); onChange && onChange(e.target.value); }}
          onFocus={() => setFocus(true)}
          onBlur={() => setFocus(false)}
          style={{
            flex: 1,
            border: "none",
            outline: "none",
            background: "transparent",
            fontFamily: "var(--font-body)",
            fontSize: "var(--text-md)",
            fontWeight: "var(--weight-medium)",
            color: "var(--text-primary)",
            minWidth: 0,
          }}
        />
      </span>
      {hint && (
        <span style={{ fontSize: "var(--text-xs)", fontWeight: "var(--weight-semibold)", color: invalid ? "var(--ff-danger)" : "var(--text-muted)" }}>
          {hint}
        </span>
      )}
    </label>
  );
}
