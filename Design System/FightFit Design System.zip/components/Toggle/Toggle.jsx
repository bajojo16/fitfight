import * as React from "react";

export function Toggle({ checked, disabled = false, onChange }) {
  const [internal, setInternal] = React.useState(!!checked);
  const on = checked !== undefined ? checked : internal;

  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      disabled={disabled}
      onClick={() => { setInternal(!on); onChange && onChange(!on); }}
      style={{
        position: "relative",
        width: 52,
        height: 30,
        flex: "0 0 auto",
        borderRadius: "var(--radius-pill)",
        border: "none",
        cursor: disabled ? "not-allowed" : "pointer",
        background: on ? "var(--color-primary)" : "var(--ff-gray-300)",
        opacity: disabled ? 0.5 : 1,
        transition: "background var(--duration-base) var(--ease-punch)",
        padding: 0,
      }}
    >
      <span
        style={{
          position: "absolute",
          top: 3,
          left: on ? 25 : 3,
          width: 24,
          height: 24,
          borderRadius: "50%",
          background: "#fff",
          boxShadow: "0 1px 3px rgba(23,21,23,0.3)",
          transition: "left var(--duration-base) var(--ease-punch)",
        }}
      />
    </button>
  );
}
