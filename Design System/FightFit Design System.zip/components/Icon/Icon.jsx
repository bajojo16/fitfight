import * as React from "react";

let loaderPromise = null;
function ensureLucide() {
  if (window.lucide) return Promise.resolve();
  if (loaderPromise) return loaderPromise;
  loaderPromise = new Promise((resolve) => {
    const existing = document.querySelector("script[data-lucide-loader]");
    if (existing) { existing.addEventListener("load", () => resolve()); return; }
    const s = document.createElement("script");
    s.src = "https://unpkg.com/lucide@0.453.0/dist/umd/lucide.min.js";
    s.setAttribute("data-lucide-loader", "");
    s.onload = () => resolve();
    document.head.appendChild(s);
  });
  return loaderPromise;
}

/** Renders a single Lucide icon as inline SVG. */
export function Icon({ name, size = 20, color = "currentColor", strokeWidth = 2 }) {
  const ref = React.useRef(null);
  const [, force] = React.useState(0);

  React.useEffect(() => {
    let cancelled = false;
    ensureLucide().then(() => {
      if (cancelled || !ref.current) return;
      const icons = window.lucide && window.lucide.icons;
      const toPascal = (n) => n.split(/[-_]/).map((p) => p.charAt(0).toUpperCase() + p.slice(1)).join("");
      const node = icons && (icons[toPascal(name)] || icons[name]);
      if (node && window.lucide.createElement) {
        const svg = window.lucide.createElement(node);
        svg.setAttribute("width", size);
        svg.setAttribute("height", size);
        svg.setAttribute("stroke", color);
        svg.setAttribute("stroke-width", strokeWidth);
        ref.current.innerHTML = "";
        ref.current.appendChild(svg);
      } else {
        force((n) => n + 1);
      }
    });
    return () => { cancelled = true; };
  }, [name, size, color, strokeWidth]);

  return (
    <span
      ref={ref}
      style={{ display: "inline-flex", width: size, height: size, flex: "0 0 auto", color }}
      aria-hidden="true"
    />
  );
}
