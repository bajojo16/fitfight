import * as React from "react";

export interface SegmentedControlProps {
  /** Option labels. */
  options: string[];
  /** Index of the active option. @default 0 */
  value?: number;
  onChange?: (index: number) => void;
  /** Render on a dark surface. @default false */
  onInk?: boolean;
}

/** Pill segmented control for 2–4 mutually exclusive options. */
export declare function SegmentedControl(props: SegmentedControlProps): React.ReactElement;
