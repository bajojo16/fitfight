/* @ds-bundle: {"format":3,"namespace":"FightFitDesignSystem_c43baf","components":[{"name":"Avatar","sourcePath":"components/Avatar/Avatar.jsx"},{"name":"Badge","sourcePath":"components/Badge/Badge.jsx"},{"name":"Button","sourcePath":"components/Button/Button.jsx"},{"name":"ExerciseRow","sourcePath":"components/ExerciseRow/ExerciseRow.jsx"},{"name":"Icon","sourcePath":"components/Icon/Icon.jsx"},{"name":"Input","sourcePath":"components/Input/Input.jsx"},{"name":"ProgressRing","sourcePath":"components/ProgressRing/ProgressRing.jsx"},{"name":"SegmentedControl","sourcePath":"components/SegmentedControl/SegmentedControl.jsx"},{"name":"StatTile","sourcePath":"components/StatTile/StatTile.jsx"},{"name":"Toggle","sourcePath":"components/Toggle/Toggle.jsx"},{"name":"WorkoutCard","sourcePath":"components/WorkoutCard/WorkoutCard.jsx"}],"sourceHashes":{"components/Avatar/Avatar.jsx":"9491136b06c5","components/Badge/Badge.jsx":"1317ce852e1b","components/Button/Button.jsx":"39874ed53366","components/ExerciseRow/ExerciseRow.jsx":"547fd0872dc1","components/Icon/Icon.jsx":"bcb61af5bd7d","components/Input/Input.jsx":"69a0d7fdc8f1","components/ProgressRing/ProgressRing.jsx":"1a2c60b6fa92","components/SegmentedControl/SegmentedControl.jsx":"dc3c17d22c4d","components/StatTile/StatTile.jsx":"a4152295aaa5","components/Toggle/Toggle.jsx":"4a8d4f08184b","components/WorkoutCard/WorkoutCard.jsx":"3ff5d0a4fb87"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.FightFitDesignSystem_c43baf = window.FightFitDesignSystem_c43baf || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/Avatar/Avatar.jsx
try { (() => {
function initials(name) {
  if (!name) return "";
  return name.trim().split(/\s+/).slice(0, 2).map(p => p[0].toUpperCase()).join("");
}
function Avatar({
  src,
  name,
  size = 44,
  status = "none",
  ring = false
}) {
  const dot = status === "online" ? "var(--ff-success)" : status === "training" ? "var(--color-primary)" : null;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      display: "inline-flex",
      width: size,
      height: size,
      flex: "0 0 auto"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: size,
      height: size,
      borderRadius: "50%",
      overflow: "hidden",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      background: "var(--ff-gray-200)",
      color: "var(--ff-gray-700)",
      fontFamily: "var(--font-body)",
      fontWeight: "var(--weight-heavy)",
      fontSize: size * 0.38,
      boxShadow: ring ? "0 0 0 2px var(--surface-page), 0 0 0 4px var(--color-primary)" : "none"
    }
  }, src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name || "",
    style: {
      width: "100%",
      height: "100%",
      objectFit: "cover"
    }
  }) : initials(name)), dot && /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      right: 0,
      bottom: 0,
      width: size * 0.28,
      height: size * 0.28,
      borderRadius: "50%",
      background: dot,
      border: "2px solid var(--surface-page)"
    }
  }));
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/Avatar/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/Icon/Icon.jsx
try { (() => {
let loaderPromise = null;
function ensureLucide() {
  if (window.lucide) return Promise.resolve();
  if (loaderPromise) return loaderPromise;
  loaderPromise = new Promise(resolve => {
    const existing = document.querySelector("script[data-lucide-loader]");
    if (existing) {
      existing.addEventListener("load", () => resolve());
      return;
    }
    const s = document.createElement("script");
    s.src = "https://unpkg.com/lucide@0.453.0/dist/umd/lucide.min.js";
    s.setAttribute("data-lucide-loader", "");
    s.onload = () => resolve();
    document.head.appendChild(s);
  });
  return loaderPromise;
}

/** Renders a single Lucide icon as inline SVG. */
function Icon({
  name,
  size = 20,
  color = "currentColor",
  strokeWidth = 2
}) {
  const ref = React.useRef(null);
  const [, force] = React.useState(0);
  React.useEffect(() => {
    let cancelled = false;
    ensureLucide().then(() => {
      if (cancelled || !ref.current) return;
      const icons = window.lucide && window.lucide.icons;
      const toPascal = n => n.split(/[-_]/).map(p => p.charAt(0).toUpperCase() + p.slice(1)).join("");
      const node = icons && (icons[toPascal(name)] || icons[name]);
      if (node && window.lucide.createElement) {
        const svg = window.lucide.createElement(node);
        svg.setAttribute("width", size);
        svg.setAttribute("height", size);
        svg.setAttribute("stroke", color);
        svg.setAttribute("stroke-width", strokeWidth);
        ref.current.innerHTML = "";
        ref.current.appendChild(svg);
      } else {
        force(n => n + 1);
      }
    });
    return () => {
      cancelled = true;
    };
  }, [name, size, color, strokeWidth]);
  return /*#__PURE__*/React.createElement("span", {
    ref: ref,
    style: {
      display: "inline-flex",
      width: size,
      height: size,
      flex: "0 0 auto",
      color
    },
    "aria-hidden": "true"
  });
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/Icon/Icon.jsx", error: String((e && e.message) || e) }); }

// components/Badge/Badge.jsx
try { (() => {
const TONES = {
  neutral: {
    soft: ["var(--ff-gray-100)", "var(--ff-gray-700)"],
    solid: ["var(--ff-ink)", "#fff"]
  },
  brand: {
    soft: ["var(--ff-orange-50)", "var(--ff-orange-700)"],
    solid: ["var(--color-primary)", "#fff"]
  },
  success: {
    soft: ["var(--ff-success-soft)", "var(--ff-success)"],
    solid: ["var(--ff-success)", "#fff"]
  },
  warning: {
    soft: ["var(--ff-warning-soft)", "var(--ff-warning)"],
    solid: ["var(--ff-warning)", "#fff"]
  },
  danger: {
    soft: ["var(--ff-danger-soft)", "var(--ff-danger)"],
    solid: ["var(--ff-danger)", "#fff"]
  }
};
function Badge({
  tone = "neutral",
  variant = "soft",
  icon,
  children
}) {
  const [bg, fg] = (TONES[tone] || TONES.neutral)[variant];
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 5,
      height: 24,
      padding: "0 10px",
      background: bg,
      color: fg,
      fontFamily: "var(--font-body)",
      fontSize: "var(--text-xs)",
      fontWeight: "var(--weight-heavy)",
      letterSpacing: "0.06em",
      textTransform: "uppercase",
      borderRadius: "var(--radius-pill)",
      whiteSpace: "nowrap",
      lineHeight: 1
    }
  }, icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 13
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/Badge/Badge.jsx", error: String((e && e.message) || e) }); }

// components/Button/Button.jsx
try { (() => {
const SIZES = {
  sm: {
    height: 36,
    padding: "0 16px",
    font: "var(--text-sm)",
    icon: 16
  },
  md: {
    height: 44,
    padding: "0 22px",
    font: "var(--text-md)",
    icon: 18
  },
  lg: {
    height: 54,
    padding: "0 30px",
    font: "var(--text-lg)",
    icon: 20
  }
};
const VARIANTS = {
  primary: {
    background: "var(--color-primary)",
    color: "#fff",
    border: "1px solid transparent"
  },
  secondary: {
    background: "var(--surface-card)",
    color: "var(--text-primary)",
    border: "1px solid var(--border-strong)"
  },
  ghost: {
    background: "transparent",
    color: "var(--text-brand)",
    border: "1px solid transparent"
  },
  danger: {
    background: "var(--ff-danger)",
    color: "#fff",
    border: "1px solid transparent"
  },
  inverse: {
    background: "#fff",
    color: "var(--ff-ink)",
    border: "1px solid transparent"
  }
};
function Button({
  variant = "primary",
  size = "md",
  block = false,
  iconLeft,
  iconRight,
  disabled = false,
  onClick,
  children
}) {
  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);
  const s = SIZES[size] || SIZES.md;
  const v = VARIANTS[variant] || VARIANTS.primary;
  const hoverBg = {
    primary: "var(--color-primary-hover)",
    secondary: "var(--ff-gray-50)",
    ghost: "var(--ff-orange-50)",
    danger: "#bf2419",
    inverse: "var(--ff-gray-100)"
  }[variant];
  const style = {
    display: block ? "flex" : "inline-flex",
    width: block ? "100%" : "auto",
    alignItems: "center",
    justifyContent: "center",
    gap: "var(--space-2)",
    height: s.height,
    padding: s.padding,
    boxSizing: "border-box",
    fontFamily: "var(--font-body)",
    fontSize: s.font,
    fontWeight: "var(--weight-heavy)",
    lineHeight: 1,
    letterSpacing: "0.01em",
    borderRadius: "var(--radius-pill)",
    cursor: disabled ? "not-allowed" : "pointer",
    opacity: disabled ? 0.45 : 1,
    background: hover && !disabled ? hoverBg : v.background,
    color: v.color,
    border: v.border,
    transform: active && !disabled ? "scale(0.97)" : "scale(1)",
    transition: "background var(--duration-fast) var(--ease-punch), transform var(--duration-fast) var(--ease-punch)",
    outline: "none",
    whiteSpace: "nowrap"
  };
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    style: style,
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setActive(false);
    },
    onMouseDown: () => setActive(true),
    onMouseUp: () => setActive(false),
    onFocus: e => e.currentTarget.style.boxShadow = "var(--focus-ring)",
    onBlur: e => e.currentTarget.style.boxShadow = "none"
  }, iconLeft && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconLeft,
    size: s.icon
  }), children, iconRight && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconRight,
    size: s.icon
  }));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/Button/Button.jsx", error: String((e && e.message) || e) }); }

// components/ExerciseRow/ExerciseRow.jsx
try { (() => {
function ExerciseRow({
  index,
  name,
  detail,
  meta,
  done = false,
  onToggle
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-4)",
      padding: "var(--space-3) var(--space-4)",
      background: "var(--surface-card)",
      border: "1px solid var(--border-subtle)",
      borderRadius: "var(--radius-md)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: 30,
      height: 30,
      flex: "0 0 auto",
      borderRadius: "var(--radius-sm)",
      background: done ? "var(--ff-success-soft)" : "var(--surface-sunken)",
      color: done ? "var(--ff-success)" : "var(--text-muted)",
      fontFamily: "var(--font-numeric)",
      fontWeight: "var(--weight-heavy)",
      fontSize: "var(--text-sm)"
    }
  }, done ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "check",
    size: 16
  }) : index), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "var(--text-md)",
      fontWeight: "var(--weight-bold)",
      color: "var(--text-primary)",
      textDecoration: done ? "line-through" : "none",
      opacity: done ? 0.55 : 1
    }
  }, name), detail && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "var(--text-sm)",
      color: "var(--text-muted)",
      fontWeight: "var(--weight-medium)"
    }
  }, detail)), meta && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-xs)",
      fontWeight: "var(--weight-bold)",
      color: "var(--text-secondary)",
      whiteSpace: "nowrap"
    }
  }, meta), /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onToggle,
    "aria-label": done ? "Mark incomplete" : "Mark complete",
    style: {
      appearance: "none",
      width: 28,
      height: 28,
      flex: "0 0 auto",
      borderRadius: "50%",
      cursor: "pointer",
      border: done ? "none" : "2px solid var(--border-strong)",
      background: done ? "var(--color-primary)" : "transparent",
      color: "#fff",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      padding: 0
    }
  }, done && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "check",
    size: 16
  })));
}
Object.assign(__ds_scope, { ExerciseRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/ExerciseRow/ExerciseRow.jsx", error: String((e && e.message) || e) }); }

// components/Input/Input.jsx
try { (() => {
function Input({
  label,
  placeholder,
  value,
  icon,
  hint,
  invalid = false,
  type = "text",
  disabled = false,
  onChange
}) {
  const [focus, setFocus] = React.useState(false);
  const [internal, setInternal] = React.useState(value || "");
  const val = value !== undefined ? value : internal;
  const borderColor = invalid ? "var(--ff-danger)" : focus ? "var(--color-primary)" : "var(--border-strong)";
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6,
      fontFamily: "var(--font-body)"
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-sm)",
      fontWeight: "var(--weight-bold)",
      color: "var(--text-primary)"
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      height: 48,
      padding: "0 16px",
      background: disabled ? "var(--ff-gray-100)" : "var(--surface-card)",
      border: `1.5px solid ${borderColor}`,
      borderRadius: "var(--radius-sm)",
      boxShadow: focus ? "var(--focus-ring)" : "none",
      transition: "border-color var(--duration-fast) var(--ease-punch), box-shadow var(--duration-fast) var(--ease-punch)",
      opacity: disabled ? 0.6 : 1
    }
  }, icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 18,
    color: "var(--text-muted)"
  }), /*#__PURE__*/React.createElement("input", {
    type: type,
    value: val,
    placeholder: placeholder,
    disabled: disabled,
    onChange: e => {
      setInternal(e.target.value);
      onChange && onChange(e.target.value);
    },
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      flex: 1,
      border: "none",
      outline: "none",
      background: "transparent",
      fontFamily: "var(--font-body)",
      fontSize: "var(--text-md)",
      fontWeight: "var(--weight-medium)",
      color: "var(--text-primary)",
      minWidth: 0
    }
  })), hint && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-xs)",
      fontWeight: "var(--weight-semibold)",
      color: invalid ? "var(--ff-danger)" : "var(--text-muted)"
    }
  }, hint));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/Input/Input.jsx", error: String((e && e.message) || e) }); }

// components/ProgressRing/ProgressRing.jsx
try { (() => {
function ProgressRing({
  value = 0,
  size = 120,
  thickness = 12,
  color = "var(--color-primary)",
  label,
  caption
}) {
  const r = (size - thickness) / 2;
  const c = 2 * Math.PI * r;
  const clamped = Math.max(0, Math.min(100, value));
  const offset = c * (1 - clamped / 100);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      width: size,
      height: size,
      flex: "0 0 auto"
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    style: {
      transform: "rotate(-90deg)"
    }
  }, /*#__PURE__*/React.createElement("circle", {
    cx: size / 2,
    cy: size / 2,
    r: r,
    fill: "none",
    stroke: "var(--surface-sunken)",
    strokeWidth: thickness
  }), /*#__PURE__*/React.createElement("circle", {
    cx: size / 2,
    cy: size / 2,
    r: r,
    fill: "none",
    stroke: color,
    strokeWidth: thickness,
    strokeLinecap: "round",
    strokeDasharray: c,
    strokeDashoffset: offset,
    style: {
      transition: "stroke-dashoffset var(--duration-slow) var(--ease-punch)"
    }
  })), (label || caption) && /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      gap: 2
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-numeric)",
      fontWeight: "var(--weight-heavy)",
      fontVariantNumeric: "tabular-nums",
      fontSize: size * 0.26,
      lineHeight: 1,
      color: "var(--text-primary)"
    }
  }, label), caption && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-body)",
      fontSize: "var(--text-xs)",
      fontWeight: "var(--weight-heavy)",
      letterSpacing: "0.08em",
      textTransform: "uppercase",
      color: "var(--text-muted)"
    }
  }, caption)));
}
Object.assign(__ds_scope, { ProgressRing });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/ProgressRing/ProgressRing.jsx", error: String((e && e.message) || e) }); }

// components/SegmentedControl/SegmentedControl.jsx
try { (() => {
function SegmentedControl({
  options = [],
  value = 0,
  onChange,
  onInk = false
}) {
  const [internal, setInternal] = React.useState(value);
  const active = value !== undefined ? value : internal;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "inline-flex",
      padding: 4,
      gap: 2,
      background: onInk ? "rgba(255,255,255,0.08)" : "var(--surface-sunken)",
      borderRadius: "var(--radius-pill)",
      border: onInk ? "1px solid var(--border-on-ink)" : "1px solid var(--border-subtle)"
    }
  }, options.map((opt, i) => {
    const on = i === active;
    return /*#__PURE__*/React.createElement("button", {
      key: i,
      type: "button",
      onClick: () => {
        setInternal(i);
        onChange && onChange(i);
      },
      style: {
        appearance: "none",
        border: "none",
        cursor: "pointer",
        padding: "8px 18px",
        borderRadius: "var(--radius-pill)",
        fontFamily: "var(--font-body)",
        fontSize: "var(--text-sm)",
        fontWeight: "var(--weight-heavy)",
        letterSpacing: "0.02em",
        background: on ? onInk ? "#fff" : "var(--ff-ink)" : "transparent",
        color: on ? onInk ? "var(--ff-ink)" : "#fff" : onInk ? "var(--text-inverse-secondary)" : "var(--text-secondary)",
        transition: "background var(--duration-fast) var(--ease-punch), color var(--duration-fast) var(--ease-punch)",
        whiteSpace: "nowrap"
      }
    }, opt);
  }));
}
Object.assign(__ds_scope, { SegmentedControl });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/SegmentedControl/SegmentedControl.jsx", error: String((e && e.message) || e) }); }

// components/StatTile/StatTile.jsx
try { (() => {
function StatTile({
  icon,
  value,
  unit,
  label,
  trend,
  trendDir = "up",
  onInk = false
}) {
  const trendColor = trendDir === "down" ? "var(--ff-danger)" : trendDir === "flat" ? "var(--text-muted)" : "var(--ff-success)";
  const trendIcon = trendDir === "down" ? "trending-down" : trendDir === "flat" ? "minus" : "trending-up";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-3)",
      padding: "var(--space-5)",
      background: onInk ? "var(--surface-ink-raised)" : "var(--surface-card)",
      border: onInk ? "1px solid var(--border-on-ink)" : "1px solid var(--border-subtle)",
      borderRadius: "var(--radius-lg)",
      boxShadow: onInk ? "none" : "var(--shadow-card)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between"
    }
  }, icon && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: 38,
      height: 38,
      borderRadius: "var(--radius-md)",
      background: "var(--ff-orange-50)",
      color: "var(--color-primary)"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 20
  })), trend && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 3,
      color: trendColor,
      fontSize: "var(--text-xs)",
      fontWeight: "var(--weight-heavy)"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: trendIcon,
    size: 14
  }), trend)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      gap: 4
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-numeric)",
      fontWeight: "var(--weight-heavy)",
      fontVariantNumeric: "tabular-nums",
      fontSize: "var(--text-stat-md)",
      lineHeight: 1,
      color: onInk ? "var(--text-inverse)" : "var(--text-primary)"
    }
  }, value), unit && /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: "var(--weight-bold)",
      fontSize: "var(--text-sm)",
      color: "var(--text-muted)"
    }
  }, unit)), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-xs)",
      fontWeight: "var(--weight-heavy)",
      letterSpacing: "0.08em",
      textTransform: "uppercase",
      color: "var(--text-muted)"
    }
  }, label));
}
Object.assign(__ds_scope, { StatTile });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/StatTile/StatTile.jsx", error: String((e && e.message) || e) }); }

// components/Toggle/Toggle.jsx
try { (() => {
function Toggle({
  checked,
  disabled = false,
  onChange
}) {
  const [internal, setInternal] = React.useState(!!checked);
  const on = checked !== undefined ? checked : internal;
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    role: "switch",
    "aria-checked": on,
    disabled: disabled,
    onClick: () => {
      setInternal(!on);
      onChange && onChange(!on);
    },
    style: {
      position: "relative",
      width: 52,
      height: 30,
      flex: "0 0 auto",
      borderRadius: "var(--radius-pill)",
      border: "none",
      cursor: disabled ? "not-allowed" : "pointer",
      background: on ? "var(--color-primary)" : "var(--ff-gray-300)",
      opacity: disabled ? 0.5 : 1,
      transition: "background var(--duration-base) var(--ease-punch)",
      padding: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      top: 3,
      left: on ? 25 : 3,
      width: 24,
      height: 24,
      borderRadius: "50%",
      background: "#fff",
      boxShadow: "0 1px 3px rgba(23,21,23,0.3)",
      transition: "left var(--duration-base) var(--ease-punch)"
    }
  }));
}
Object.assign(__ds_scope, { Toggle });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/Toggle/Toggle.jsx", error: String((e && e.message) || e) }); }

// components/WorkoutCard/WorkoutCard.jsx
try { (() => {
function WorkoutCard({
  image,
  tag,
  title,
  duration,
  level = "Intermediate",
  kcal,
  onClick
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      position: "relative",
      display: "flex",
      flexDirection: "column",
      justifyContent: "flex-end",
      minHeight: 220,
      padding: "var(--space-5)",
      borderRadius: "var(--radius-lg)",
      overflow: "hidden",
      cursor: onClick ? "pointer" : "default",
      background: "var(--ff-gray-800)",
      boxShadow: hover ? "var(--shadow-overlay)" : "var(--shadow-card)",
      transform: hover ? "translateY(-3px)" : "translateY(0)",
      transition: "transform var(--duration-base) var(--ease-punch), box-shadow var(--duration-base) var(--ease-punch)"
    }
  }, image && /*#__PURE__*/React.createElement("img", {
    src: image,
    alt: "",
    style: {
      position: "absolute",
      inset: 0,
      width: "100%",
      height: "100%",
      objectFit: "cover",
      transform: hover ? "scale(1.06)" : "scale(1)",
      transition: "transform var(--duration-slow) var(--ease-punch)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      background: "linear-gradient(180deg, rgba(23,21,23,0) 30%, rgba(23,21,23,0.82) 100%)"
    }
  }), tag && /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: "var(--space-4)",
      left: "var(--space-4)"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: "brand",
    variant: "solid"
  }, tag)), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-3)"
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontFamily: "var(--font-display)",
      fontWeight: "var(--weight-bold)",
      textTransform: "uppercase",
      lineHeight: "var(--leading-display)",
      letterSpacing: "var(--tracking-display)",
      fontSize: "var(--text-display-sm)",
      color: "#fff"
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-4)",
      color: "rgba(255,255,255,0.86)",
      fontSize: "var(--text-sm)",
      fontWeight: "var(--weight-bold)"
    }
  }, duration && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 5
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "clock",
    size: 15
  }), " ", duration), kcal && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 5
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "flame",
    size: 15
  }), " ", kcal, " kcal"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 5
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "signal",
    size: 15
  }), " ", level))));
}
Object.assign(__ds_scope, { WorkoutCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/WorkoutCard/WorkoutCard.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.ExerciseRow = __ds_scope.ExerciseRow;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.ProgressRing = __ds_scope.ProgressRing;

__ds_ns.SegmentedControl = __ds_scope.SegmentedControl;

__ds_ns.StatTile = __ds_scope.StatTile;

__ds_ns.Toggle = __ds_scope.Toggle;

__ds_ns.WorkoutCard = __ds_scope.WorkoutCard;

})();
