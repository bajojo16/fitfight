import * as React from "react";

function initials(name) {
  if (!name) return "";
  return name.trim().split(/\s+/).slice(0, 2).map((p) => p[0].toUpperCase()).join("");
}

export function Avatar({ src, name, size = 44, status = "none", ring = false }) {
  const dot = status === "online" ? "var(--ff-success)" : status === "training" ? "var(--color-primary)" : null;

  return (
    <span style={{ position: "relative", display: "inline-flex", width: size, height: size, flex: "0 0 auto" }}>
      <span
        style={{
          width: size,
          height: size,
          borderRadius: "50%",
          overflow: "hidden",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          background: "var(--ff-gray-200)",
          color: "var(--ff-gray-700)",
          fontFamily: "var(--font-body)",
          fontWeight: "var(--weight-heavy)",
          fontSize: size * 0.38,
          boxShadow: ring ? "0 0 0 2px var(--surface-page), 0 0 0 4px var(--color-primary)" : "none",
        }}
      >
        {src ? (
          <img src={src} alt={name || ""} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
        ) : (
          initials(name)
        )}
      </span>
      {dot && (
        <span
          style={{
            position: "absolute",
            right: 0,
            bottom: 0,
            width: size * 0.28,
            height: size * 0.28,
            borderRadius: "50%",
            background: dot,
            border: "2px solid var(--surface-page)",
          }}
        />
      )}
    </span>
  );
}
