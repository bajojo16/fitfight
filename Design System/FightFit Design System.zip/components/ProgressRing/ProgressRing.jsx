import * as React from "react";

export function ProgressRing({
  value = 0,
  size = 120,
  thickness = 12,
  color = "var(--color-primary)",
  label,
  caption,
}) {
  const r = (size - thickness) / 2;
  const c = 2 * Math.PI * r;
  const clamped = Math.max(0, Math.min(100, value));
  const offset = c * (1 - clamped / 100);

  return (
    <div style={{ position: "relative", width: size, height: size, flex: "0 0 auto" }}>
      <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--surface-sunken)" strokeWidth={thickness} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={color}
          strokeWidth={thickness}
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={offset}
          style={{ transition: "stroke-dashoffset var(--duration-slow) var(--ease-punch)" }}
        />
      </svg>
      {(label || caption) && (
        <div
          style={{
            position: "absolute",
            inset: 0,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            gap: 2,
          }}
        >
          {label && (
            <span style={{ fontFamily: "var(--font-numeric)", fontWeight: "var(--weight-heavy)", fontVariantNumeric: "tabular-nums", fontSize: size * 0.26, lineHeight: 1, color: "var(--text-primary)" }}>
              {label}
            </span>
          )}
          {caption && (
            <span style={{ fontFamily: "var(--font-body)", fontSize: "var(--text-xs)", fontWeight: "var(--weight-heavy)", letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--text-muted)" }}>
              {caption}
            </span>
          )}
        </div>
      )}
    </div>
  );
}
