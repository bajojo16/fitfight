import * as React from "react";
import { Icon } from "../Icon/Icon.jsx";

export function ExerciseRow({ index, name, detail, meta, done = false, onToggle }) {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: "var(--space-4)",
        padding: "var(--space-3) var(--space-4)",
        background: "var(--surface-card)",
        border: "1px solid var(--border-subtle)",
        borderRadius: "var(--radius-md)",
      }}
    >
      <span
        style={{
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          width: 30,
          height: 30,
          flex: "0 0 auto",
          borderRadius: "var(--radius-sm)",
          background: done ? "var(--ff-success-soft)" : "var(--surface-sunken)",
          color: done ? "var(--ff-success)" : "var(--text-muted)",
          fontFamily: "var(--font-numeric)",
          fontWeight: "var(--weight-heavy)",
          fontSize: "var(--text-sm)",
        }}
      >
        {done ? <Icon name="check" size={16} /> : index}
      </span>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: "var(--text-md)", fontWeight: "var(--weight-bold)", color: "var(--text-primary)", textDecoration: done ? "line-through" : "none", opacity: done ? 0.55 : 1 }}>
          {name}
        </div>
        {detail && <div style={{ fontSize: "var(--text-sm)", color: "var(--text-muted)", fontWeight: "var(--weight-medium)" }}>{detail}</div>}
      </div>
      {meta && <span style={{ fontSize: "var(--text-xs)", fontWeight: "var(--weight-bold)", color: "var(--text-secondary)", whiteSpace: "nowrap" }}>{meta}</span>}
      <button
        type="button"
        onClick={onToggle}
        aria-label={done ? "Mark incomplete" : "Mark complete"}
        style={{
          appearance: "none",
          width: 28,
          height: 28,
          flex: "0 0 auto",
          borderRadius: "50%",
          cursor: "pointer",
          border: done ? "none" : "2px solid var(--border-strong)",
          background: done ? "var(--color-primary)" : "transparent",
          color: "#fff",
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          padding: 0,
        }}
      >
        {done && <Icon name="check" size={16} />}
      </button>
    </div>
  );
}
