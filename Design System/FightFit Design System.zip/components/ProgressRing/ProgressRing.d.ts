import * as React from "react";

export interface ProgressRingProps {
  /** Completion 0–100. @default 0 */
  value?: number;
  /** Outer diameter in px. @default 120 */
  size?: number;
  /** Stroke thickness in px. @default 12 */
  thickness?: number;
  /** Ring color. @default brand orange */
  color?: string;
  /** Large centered value, e.g. "72%". */
  label?: string;
  /** Small caption under the label. */
  caption?: string;
}

/** Circular progress indicator for goals, macros, and session completion. */
export declare function ProgressRing(props: ProgressRingProps): React.ReactElement;
