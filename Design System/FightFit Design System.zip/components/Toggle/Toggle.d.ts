import * as React from "react";

export interface ToggleProps {
  checked?: boolean;
  disabled?: boolean;
  onChange?: (checked: boolean) => void;
}

/** Binary on/off switch with brand-orange active track. */
export declare function Toggle(props: ToggleProps): React.ReactElement;
