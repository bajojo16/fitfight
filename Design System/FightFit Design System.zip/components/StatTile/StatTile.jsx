import * as React from "react";
import { Icon } from "../Icon/Icon.jsx";

export function StatTile({ icon, value, unit, label, trend, trendDir = "up", onInk = false }) {
  const trendColor = trendDir === "down" ? "var(--ff-danger)" : trendDir === "flat" ? "var(--text-muted)" : "var(--ff-success)";
  const trendIcon = trendDir === "down" ? "trending-down" : trendDir === "flat" ? "minus" : "trending-up";

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        gap: "var(--space-3)",
        padding: "var(--space-5)",
        background: onInk ? "var(--surface-ink-raised)" : "var(--surface-card)",
        border: onInk ? "1px solid var(--border-on-ink)" : "1px solid var(--border-subtle)",
        borderRadius: "var(--radius-lg)",
        boxShadow: onInk ? "none" : "var(--shadow-card)",
      }}
    >
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        {icon && (
          <span
            style={{
              display: "inline-flex",
              alignItems: "center",
              justifyContent: "center",
              width: 38,
              height: 38,
              borderRadius: "var(--radius-md)",
              background: "var(--ff-orange-50)",
              color: "var(--color-primary)",
            }}
          >
            <Icon name={icon} size={20} />
          </span>
        )}
        {trend && (
          <span style={{ display: "inline-flex", alignItems: "center", gap: 3, color: trendColor, fontSize: "var(--text-xs)", fontWeight: "var(--weight-heavy)" }}>
            <Icon name={trendIcon} size={14} />
            {trend}
          </span>
        )}
      </div>
      <div style={{ display: "flex", alignItems: "baseline", gap: 4 }}>
        <span style={{ fontFamily: "var(--font-numeric)", fontWeight: "var(--weight-heavy)", fontVariantNumeric: "tabular-nums", fontSize: "var(--text-stat-md)", lineHeight: 1, color: onInk ? "var(--text-inverse)" : "var(--text-primary)" }}>
          {value}
        </span>
        {unit && <span style={{ fontWeight: "var(--weight-bold)", fontSize: "var(--text-sm)", color: "var(--text-muted)" }}>{unit}</span>}
      </div>
      <span style={{ fontSize: "var(--text-xs)", fontWeight: "var(--weight-heavy)", letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--text-muted)" }}>
        {label}
      </span>
    </div>
  );
}
