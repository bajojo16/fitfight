import * as React from "react";

export interface AvatarProps {
  /** Image URL. Falls back to initials when absent. */
  src?: string;
  /** Name used for initials + alt text. */
  name?: string;
  /** Diameter in px. @default 44 */
  size?: number;
  /** Status dot. @default "none" */
  status?: "none" | "online" | "training";
  /** Orange ring around the avatar. @default false */
  ring?: boolean;
}

/** Circular user avatar with optional status dot and ring. */
export declare function Avatar(props: AvatarProps): React.ReactElement;
