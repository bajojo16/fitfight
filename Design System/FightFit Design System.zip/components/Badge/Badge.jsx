import * as React from "react";
import { Icon } from "../Icon/Icon.jsx";

const TONES = {
  neutral: { soft: ["var(--ff-gray-100)", "var(--ff-gray-700)"], solid: ["var(--ff-ink)", "#fff"] },
  brand: { soft: ["var(--ff-orange-50)", "var(--ff-orange-700)"], solid: ["var(--color-primary)", "#fff"] },
  success: { soft: ["var(--ff-success-soft)", "var(--ff-success)"], solid: ["var(--ff-success)", "#fff"] },
  warning: { soft: ["var(--ff-warning-soft)", "var(--ff-warning)"], solid: ["var(--ff-warning)", "#fff"] },
  danger: { soft: ["var(--ff-danger-soft)", "var(--ff-danger)"], solid: ["var(--ff-danger)", "#fff"] },
};

export function Badge({ tone = "neutral", variant = "soft", icon, children }) {
  const [bg, fg] = (TONES[tone] || TONES.neutral)[variant];
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 5,
        height: 24,
        padding: "0 10px",
        background: bg,
        color: fg,
        fontFamily: "var(--font-body)",
        fontSize: "var(--text-xs)",
        fontWeight: "var(--weight-heavy)",
        letterSpacing: "0.06em",
        textTransform: "uppercase",
        borderRadius: "var(--radius-pill)",
        whiteSpace: "nowrap",
        lineHeight: 1,
      }}
    >
      {icon && <Icon name={icon} size={13} />}
      {children}
    </span>
  );
}
